import json

class Room:
    def __init__(self, room_number, room_type, price, rating):
        self.room_number = room_number
        self.room_type = room_type
        self.price = price
        self.rating = rating

    def to_dict(self):
        return {
            "room_number": self.room_number,
            "room_type": self.room_type,
            "price": self.price,
            "rating": self.rating
        }


class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.history = []

    def add_to_history(self, room):
        self.history.append(room)


class Admin(User):
    def __init__(self, username, password):
        super().__init__(username, password)


class HotelSystem:
    def __init__(self):
        self.rooms = []
        self.users = {}
        self.current_user = None
        self.load_rooms()
        self.load_users()  # Загружаем пользователей

    def load_rooms(self):
        try:
            with open('rooms.json', 'r') as file:
                rooms_data = json.load(file)
                for room in rooms_data:
                    self.rooms.append(Room(**room))
        except FileNotFoundError:
            print("Файл с данными о номерах не найден. Используйте функцию добавления номера.")

    def save_rooms(self):
        with open('rooms.json', 'w') as file:
            json.dump([room.to_dict() for room in self.rooms], file)

    def load_users(self):
        try:
            with open('users.json', 'r') as file:
                users_data = json.load(file)
                for user in users_data:
                    if 'is_admin' in user and user['is_admin']:
                        self.users[user['username']] = Admin(user['username'], user['password'])
                    else:
                        self.users[user['username']] = User(user['username'], user['password'])
        except FileNotFoundError:
            print("Файл с пользователями не найден. Создаем пользователя админа.")
            self.create_admin()

    def save_users(self):
        with open('users.json', 'w') as file:
            json.dump([{"username": user.username, "password": user.password, "is_admin": isinstance(user, Admin)} for user in self.users.values()], file)

    def create_admin(self):
        admin_username = "admin"
        admin_password = "admin123"
        self.users[admin_username] = Admin(admin_username, admin_password)
        self.save_users()
        print(f"Создан пользователь администратор: {admin_username} с паролем: {admin_password}")

    def authenticate_user(self):
        username = input("Логин: ")
        password = input("Пароль: ")
        if username in self.users and self.users[username].password == password:
            self.current_user = self.users[username]
            print(f"Добро пожаловать, {username}!")
            return True
        print("Неверный логин или пароль.")
        return False

    def show_user_menu(self):
        while True:
            print("\nВыберите действие:")
            print("1. Просмотреть каталог номеров")
            print("2. Найти номер")
            print("3. Сортировать номера по рейтингу")
            print("4. Забронировать номер")
            print("5. Посмотреть историю бронирований")
            if isinstance(self.current_user, Admin):
                print("6. Добавить номер")
                print("7. Удалить номер")
            print("0. Выйти")

            choice = input("Ваш выбор: ")
            if choice == '1':
                self.list_rooms()
            elif choice == '2':
                self.find_room()
            elif choice == '3':
                self.sort_rooms()
            elif choice == '4':
                self.book_room()
            elif choice == '5':
                self.view_history()
            elif choice == '6' and isinstance(self.current_user, Admin):
                self.add_room()
            elif choice == '7' and isinstance(self.current_user, Admin):
                self.remove_room()
            elif choice == '0':
                break
            else:
                print("Некорректный выбор.")

    def list_rooms(self):
        if not self.rooms:
            print("Нет доступных номеров.")
            return
        for room in self.rooms:
            print(f"{room.room_number} | Тип: {room.room_type} | Цена: {room.price} | Рейтинг: {room.rating}")

    def find_room(self):
        room_number = input("Введите номер комнаты: ")
        room_found = next((room for room in self.rooms if room.room_number == room_number), None)
        if room_found:
            print(f"Номер найден: {room_found.room_number}, Тип: {room_found.room_type}, Цена: {room_found.price}, Рейтинг: {room_found.rating}")
        else:
            print("Номер не найден.")

    def sort_rooms(self):
        self.rooms.sort(key=lambda room: room.rating, reverse=True)
        print("Номера отсортированы по рейтингу.")

    def book_room(self):
        room_number = input("Введите номер комнаты для бронирования: ")
        room_to_book = next((room for room in self.rooms if room.room_number == room_number), None)
        if room_to_book:
            self.current_user.add_to_history(room_to_book)
            print(f"Номер {room_number} успешно забронирован.")
        else:
            print("Номер не найден.")

    def view_history(self):
        if not self.current_user.history:
            print("История бронирований пуста.")
        else:
            print("История бронирований:")
            for room in self.current_user.history:
                print(f"Номер: {room.room_number}, Тип: {room.room_type}")

    def add_room(self):
        room_number = input("Введите номер комнаты: ")
        room_type = input("Введите тип комнаты: ")
        price = float(input("Введите цену: "))
        rating = float(input("Введите рейтинг: "))
        new_room = Room(room_number, room_type, price, rating)
        self.rooms.append(new_room)
        self.save_rooms()
        print(f"Номер {room_number} добавлен.")

    def remove_room(self):
        room_number = input("Введите номер комнаты для удаления: ")
        self.rooms = [room for room in self.rooms if room.room_number != room_number]
        self.save_rooms()
        print(f"Номер {room_number} удален.")


def main():
    system = HotelSystem()
    while True:
        print("\n1. Регистрация")
        print("2. Вход")
        print("3. Выйти")
        choice = input("Ваш выбор: ")

        if choice == '1':
            username = input("Введите имя пользователя: ")
            password = input("Введите пароль: ")
            if username in system.users:
                print("Пользователь с таким именем уже существует.")
            else:
                system.users[username] = User(username, password)
                system.save_users()
                print(f"Пользователь '{username}' успешно зарегистрирован.")

        elif choice == '2':
            if system.authenticate_user():
                system.show_user_menu()
        elif choice == '3':
            break
        else:
            print("Некорректный выбор.")

if __name__ == '__main__':
    main()

'''import json

class Room:
    def __init__(self, room_number, room_type, price, rating):
        self.room_number = room_number
        self.room_type = room_type
        self.price = price
        self.rating = rating

    def to_dict(self):
        return {
            "room_number": self.room_number,
            "room_type": self.room_type,
            "price": self.price,
            "rating": self.rating
        }

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.history = []

    def add_to_history(self, room):
        self.history.append(room)

class HotelSystem:
    def __init__(self):
        self.rooms = []
        self.users = {}
        self.current_user = None
        self.load_users()  # Загружаем пользователей

    def load_rooms(self):
        try:
            with open('rooms.json', 'r') as file:
                rooms_data = json.load(file)
                for room in rooms_data:
                    self.rooms.append(Room(**room))
        except FileNotFoundError:
            print("Файл с данными о номерах не найден. Используйте функцию добавления номера.")

    def save_rooms(self):
        with open('rooms.json', 'w') as file:
            json.dump([room.to_dict() for room in self.rooms], file)

    def load_users(self):
        try:
            with open('users.json', 'r') as file:
                users_data = json.load(file)
                for user in users_data:
                    self.users[user['username']] = User(user['username'], user['password'])
        except FileNotFoundError:
            print("Файл с пользователями не найден. Создаем пользователя админа.")
            self.create_admin()

    def save_users(self):
        with open('users.json', 'w') as file:
            json.dump([{"username": user.username, "password": user.password} for user in self.users.values()], file)

    def create_admin(self):
        admin_username = "admin"
        admin_password = "admin123"
        self.users[admin_username] = User(admin_username, admin_password)
        self.save_users()
        print(f"Создан пользователь администратор: {admin_username} с паролем: {admin_password}")

    def authenticate_user(self):
        username = input("Логин: ")
        password = input("Пароль: ")
        if username in self.users and self.users[username].password == password:
            self.current_user = self.users[username]
            print(f"Добро пожаловать, {username}!")
            return True
        print("Неверный логин или пароль.")
        return False

    def show_user_menu(self):
        while True:
            print("\nВыберите действие:")
            print("1. Просмотреть каталог номеров")
            print("2. Найти номер")
            print("3. Сортировать номера по рейтингу")
            print("4. Забронировать номер")
            print("5. Посмотреть историю бронирований")
            print("6. Выйти")

            choice = input("Ваш выбор: ")
            if choice == '1':
                self.list_rooms()
            elif choice == '2':
                self.find_room()
            elif choice == '3':
                self.sort_rooms()
            elif choice == '4':
                self.book_room()
            elif choice == '5':
                self.view_history()
            elif choice == '6':
                break
            else:
                print("Некорректный ввод, попробуйте еще раз.")

    def list_rooms(self):
        if not self.rooms:
            print("Каталог номеров пуст.")
            return
        print("\nКаталог номеров:")
        for room in self.rooms:
            print(f"Номер: {room.room_number}, Тип: {room.room_type}, Цена: {room.price}, Рейтинг: {room.rating}")

    def find_room(self):
        room_type = input("Введите тип номера для поиска: ")
        found_rooms = list(filter(lambda room: room.room_type.lower() == room_type.lower(), self.rooms))
        if found_rooms:
            print("Найденные номера:")
            for room in found_rooms:
                print(f"Номер: {room.room_number}, Тип: {room.room_type}, Цена: {room.price}, Рейтинг: {room.rating}")
        else:
            print("Номера не найдены.")

    def sort_rooms(self):
        sorted_rooms = sorted(self.rooms, key=lambda room: room.rating, reverse=True)
        print("Номера отсортированы по рейтингу:")
        for room in sorted_rooms:
            print(f"Номер: {room.room_number}, Тип: {room.room_type}, Цена: {room.price}, Рейтинг: {room.rating}")

    def book_room(self):
        room_number = input("Введите номер, который хотите забронировать: ")
        for room in self.rooms:
            if room.room_number == room_number:
                self.current_user.add_to_history(room)
                print(f"Вы успешно забронировали номер {room_number}.")
                return
        print("Номер не найден.")

    def view_history(self):
        if self.current_user.history:
            print("История бронирований:")
            for room in self.current_user.history:
                print(f"Номер: {room.room_number}, Тип: {room.room_type}, Цена: {room.price}, Рейтинг: {room.rating}")
        else:
            print("История бронирований пуста.")

    def add_user(self):
        username = input("Введите имя пользователя: ")
        password = input("Введите пароль: ")
        self.users[username] = User(username, password)
        self.save_users()
        print("Пользователь успешно добавлен.")

    def admin_menu(self):
        while True:
            print("\nВыберите действие:")
            print("1. Просмотреть все номера")
            print("2. Добавить номер")
            print("3. Удалить номер")
            print("4. Редактировать данные о номере")
            print("5. Выйти")

            choice = input("Ваш выбор: ")
            if choice == '1':
                self.list_rooms()  # Метод для просмотра всех номеров
            elif choice == '2':
                self.add_room()
            elif choice == '3':
                self.remove_room()
            elif choice == '4':
                self.edit_room()
            elif choice == '5':
                break
            else:
                print("Некорректный ввод, попробуйте еще раз.")

    def add_room(self):
        room_number = input("Введите номер: ")
        room_type = input("Введите тип номера: ")
        price = input("Введите цену: ")
        rating = input("Введите рейтинг: ")
        self.rooms.append(Room(room_number, room_type, float(price), float(rating)))
        self.save_rooms()
        print("Номер добавлен.")

    def remove_room(self):
        room_number = input("Введите номер для удаления: ")
        self.rooms = [room for room in self.rooms if room.room_number != room_number]
        self.save_rooms()
        print("Номер удален.")

    def edit_room(self):
        room_number = input("Введите номер для редактирования: ")
        for room in self.rooms:
            if room.room_number == room_number:
                room_type = input("Введите новый тип номера: ")
                price = input("Введите новую цену: ")
                rating = input("Введите новый рейтинг: ")
                room.room_type = room_type
                room.price = float(price)
                room.rating = float(rating)
                self.save_rooms()
                print("Данные о номере обновлены.")
                return
        print("Номер не найден.")

def main():
    hotel_system = HotelSystem()
    hotel_system.load_rooms()

    while True:
        print("\nДобро пожаловать в систему управления гостиницей!")
        print("1. Войти как пользователь")
        print("2. Войти как администратор")
        print("3. Добавить пользователя (администратор)")
        print("4. Выйти")

        choice = input("Ваш выбор: ")
        if choice == '1':
            if hotel_system.authenticate_user():
                hotel_system.show_user_menu()
        elif choice == '2':
            if hotel_system.authenticate_user() and hotel_system.current_user.username == "admin":
                hotel_system.admin_menu()
            else:
                print("Вы должны войти как администратор.")
        elif choice == '3':
            hotel_system.add_user()
        elif choice == '4':
            print("Выход из системы. До свидания!")
            break
        else:
            print("Некорректный ввод.")

if __name__ == "__main__":
    main()'''




#
#
# import time
# import random
#
# def print_delayed(text, delay=1):
#     for char in text:
#         print(char, end='', flush=True)
#         time.sleep(0.05)
#     print()
#     time.sleep(delay)
#
#
# def start_game():
#     print_delayed("Вы один из самых богатых людей ОАЭ, имеете огромное влияние и успех, но что-то пошло не так....")
#     print_delayed("Итак, Вы находитесь в холодной камере одной из французских тюрем...")
#     time.sleep(1)
#
#     print_delayed("Ваша цель — сбежать, ради своих 100 детишек! Что вы будете делать?")
#     print_delayed("1. Осмотреть камеру")
#     print_delayed("2. Поговорить с сокамерником")
#
#     choice1 = input("Выберите 1 или 2: ")
#
#     if choice1 == '1':
#         explore_cell()
#     elif choice1 == '2':
#         talk_to_cellmate()
#     else:
#         print_delayed("Неверный ввод. Игра завершена.")
#
#
# def explore_cell():
#     print_delayed("Вы осматриваете свою камеру и замечаете трещину в стене.")
#     print_delayed("Также вы видите окно, но оно заперто решеткой.")
#
#     print_delayed("Что вы будете делать?")
#     print_delayed("1. Пытаться снести стену, как в 2010 году")
#     print_delayed("2. Попробовать открыть окно")
#
#     choice2 = input("Выберите 1 или 2: ")
#
#     if choice2 == '1':
#         print_delayed("Вы сносите стену, но попадаете в соседнюю камеру...")
#         end_game(
#             "Соседей не было и вы остались в ловушке, издалека слышен крик охраны 'Durov, ramène le mur!', что переводится как 'Дуров, верни стену!'.")
#     elif choice2 == '2':
#         print_delayed("Вы долго пытались открыть окно, но оно слишком крепкое.")
#         end_game("Ваши усилия привлекли внимание охраны.")
#     else:
#         print_delayed("Неверный ввод. Игра завершена.")
#
#
# def talk_to_cellmate():
#     print_delayed("Вы начинаете разговор с сокамерником.")
#     print_delayed("Он предлагает вам план побега, но вам нужно принять решение.")
#
#     print_delayed("Что вы хотите сделать?")
#     print_delayed("1. Согласиться на план сокамерника")
#     print_delayed("2. Отклонить предложение и действовать самостоятельно")
#
#     choice3 = input("Выберите 1 или 2: ")
#
#     if choice3 == '1':
#         print_delayed("Вы и ваш сокамерник начали планировать побег. Но охрана заметила вас!")
#         fight_guard()
#     elif choice3 == '2':
#         print_delayed("Вы решили действовать в одиночку и пытаетесь придумать свой собственный план.")
#         explore_cell()
#     else:
#         print_delayed("Неверный ввод. Игра завершена.")
#
#
# def fight_guard():
#     print_delayed("Вы сталкиваетесь с охранником! У вас есть несколько бумажных самолетиков, которые вы сделали ранее.")
#     print_delayed("Как вы хотите с ним справиться?")
#
#     print_delayed("1. Бросить в охранника самолетики")
#     print_delayed("2. Попробовать отвлечь охранника и сбежать")
#
#     choice4 = input("Выберите 1 или 2: ")
#
#     if choice4 == '1':
#         paper_airplane_battle()
#     elif choice4 == '2':
#         distract_guard_and_escape()
#     else:
#         print_delayed("Неверный ввод. Игра завершена.")
#
#
# def paper_airplane_battle():
#     print_delayed("Вы быстро запускаете самолетики в сторону охранника!")
#     for i in range(3):
#         print_delayed(f"Бум! Самолетик {i + 1} попал в охранника!")
#         time.sleep(0.5)
#
#     print_delayed("Охранник растерян и начинает отступать, вы видите возможность сбежать!")
#     print_delayed("Вам удалось сбежать из камеры!")
#     print_delayed("Вы на свободе, теперь нужно добраться до выхода из тюрьмы.")
#     end_game("Поздравляем! Вы смогли сбежать, вы спасены и дети не остались без отца и алиментов!!!!")
#
#
# def distract_guard_and_escape():
#     print_delayed("Вы бросаете свои вещи в другую сторону, чтобы отвлечь охранника.")
#     print_delayed("Пока охранник смотрит, вы медленно крадётесь к выходу.")
#
#     if random.random() > 0.5:
#         print_delayed("Вы успешно прошли мимо охранника и выбрались из тюрьмы!")
#         end_game("Поздравляем! Вы на свободе!")
#     else:
#         print_delayed("К сожалению, охранник заметил вас и схватил!")
#         end_game("Игра окончена. Вас поймали.")
#
#
#
# def end_game(message):
#     print_delayed(message)
#     print_delayed("Спасибо за игру!")
#     exit()
#
#
# if __name__ == "__main__":
#     start_game()